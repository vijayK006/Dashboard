import React from 'react'

const Footer = () => {
  return (
    <>

        <div className='footer-body'>
   <div className='footer'>
<p>
Copyright © [Year] [Your Name or Your Company Name]</p>
      </div>
    </div>

  
   
    </>
  )
}

export default Footer
